import React from 'react';
import image1 from '../images/dg.png'; 
import image2 from '../images/pouletpanee1.png';
import Style from './styleEtudiant';

const HeaderEtudiant = () => {
  return (
    <>
        <Style/>
        <header className="header-etudiant" style={{position: 'relative', background: 'linear-gradient(180deg, rgba(14, 14, 14, 1) 5%, rgba(207, 189, 151, 1) 100%)', color: 'white', padding: '10px',height: '300px', textAlign: 'center', overflow: 'hidden'}}>
        <div className="header-container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: '1200px', margin: '0 auto'}}>
            <img src={image1} alt="Dish 1" className="header-image" style={{width: '200px', height: '200px', position: 'absolute', left: '0', bottom: '0'}}/>

            <div className="header-text" style={{flexGrow: 1, padding: '0 20px'}}>
            <h1 className="header-title" >ZeDuc Sp@ce</h1>
            <h2 className="header-subtitle">Votre espace de goût et de détente</h2>
            <p className="header-description">
                Savourez chaque moment, plongez dans des délices uniques avec une vue imprenable sur la Dibamba et une ambiance à savourer.
            </p>
            </div>

            <img src={image2} alt="Dish 2" className="header-image" style={{width: '200px', height: '200px', borderRadius: '50%' }}/>
        </div>
        </header>
    </>
  );
};

export default HeaderEtudiant;
  

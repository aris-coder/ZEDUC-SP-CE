import React from 'react';

const Style = () => {
  return (
    <style>
      {`
        @import url('https://fonts.googleapis.com/css2?family=Milonga&display=swap');
        
        * {
          font-family: 'Milonga', sans-serif;
        }

        .navbar {
          background-color: #000;
          padding: 10px;
          border-bottom: 1px solid white;
        }

        .navLink {
          color: white;
          font-size: 18px;
          margin-right: 20px;
        }

        .navLink:hover {
          color: #ccc; 
        }

        .dropdownToggle {
          background-color: #fff;
          height: 25px;
          font-size: 15px;
        }

        .header-title {
          font-family: 'Milonga', sans-serif; 
          font-size: 3rem;
          margin-bottom: 10px;
        }

        .header-subtitle {
          font-family: 'Milonga', sans-serif; 
          font-size: 1.5rem;
          margin-bottom: 10px;
        }

        .header-description {
          font-family: 'Milonga', sans-serif; 
          font-size: 1.2rem;
        }
      `}
    </style>
  );
};

export default Style;

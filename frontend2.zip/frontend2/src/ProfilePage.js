// /src/components/ProfilePage.js
import React from 'react';
import './ProfilePage.css';  // Importez le fichier CSS spécifique pour la page de profil

function ProfilePage() {
    return (
        <div className="profile-page">
            <header>
                <h1>Profil</h1>
                <div className="profile-details">
                    <img src="/path-to-avatar.png" alt="Avatar" className="avatar" />
                    <h2>TCHAKOKAM KEINE</h2>
                    <p>ÉTUDIANT | 259 points</p>
                </div>
            </header>

            <section className="profile-settings">
                <h3>Paramètres du profil</h3>
                <ul>
                    <li>Nom: <button>Modifier</button></li>
                    <li>Téléphone: <button>Modifier</button></li>
                    <li>Email: <button>Modifier</button></li>
                    <li>Mot de passe: <button>Modifier</button></li>
                </ul>
            </section>

            <section className="fidelity-points">
                <h3>Points de fidélité</h3>
                <div className="points">
                    <div className="current-points">Vos reçus: <strong>230</strong> pts</div>
                    <div className="active-points">Vos actifs: <strong>30</strong> pts</div>
                </div>
                <div className="referral-code">
                    <h4>Parrainage</h4>
                    <p>Code de parrainage: <strong>QCWi34</strong></p>
                </div>
            </section>

            <section className="students-referred">
                <h3>Étudiants parrainés</h3>
                <ul>
                    <li>Jean M. <span>Validé</span></li>
                    <li>Andreia C. <span>Non validé</span></li>
                    <li>Cathy N. <span>Non validé</span></li>
                </ul>
                <button className="btn-disconnect">Déconnecter</button>
            </section>
        </div>
    );
}

export default ProfilePage;
